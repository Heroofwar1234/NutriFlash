package a01784773.tec.mx.nutriflash.database

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation

data class RecetaConIngredientes(
    @Embedded val receta: Receta,
    @Relation(
        parentColumn = "id",
        entityColumn = "id",
        associateBy = Junction(
            value = RecetaIngredienteCrossRef::class,
            parentColumn = "idReceta",
            entityColumn = "idIngrediente"
        )
    )
    val ingredientes: List<Ingrediente>
)