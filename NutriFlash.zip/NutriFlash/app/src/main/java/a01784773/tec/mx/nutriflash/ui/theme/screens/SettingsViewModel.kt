package a01784773.tec.mx.nutriflash.ui.theme.screens

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class Difficulty {
    Facil, Intermedio, Dificil
}

data class SettingsState(
    val profiles: List<String> = listOf("Default"),
    val selectedProfile: String = "Default",
    val newProfileName: String = "",
    val difficulty: Difficulty = Difficulty.Facil,
    val isProfileSectionExpanded: Boolean = false
)

class SettingsViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsState())
    val uiState: StateFlow<SettingsState> = _uiState.asStateFlow()

    fun onNewProfileNameChange(name: String) {
        _uiState.update { it.copy(newProfileName = name) }
    }

    fun onAddProfile() {
        _uiState.update { currentState ->
            if (currentState.newProfileName.isNotBlank() && !currentState.profiles.contains(currentState.newProfileName)) {
                currentState.copy(
                    profiles = currentState.profiles + currentState.newProfileName,
                    newProfileName = "" // Clear the text field
                )
            } else {
                currentState
            }
        }
    }

    fun onProfileSelected(profile: String) {
        _uiState.update { it.copy(selectedProfile = profile, isProfileSectionExpanded = false) }
    }

    fun onDifficultyChange(difficulty: Difficulty) {
        _uiState.update { it.copy(difficulty = difficulty) }
    }

    fun onExpandProfiles(isExpanded: Boolean) {
        _uiState.update { it.copy(isProfileSectionExpanded = isExpanded) }
    }
}
