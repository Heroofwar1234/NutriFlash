package a01784773.tec.mx.nutriflash.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface IngredienteDao {
    @Insert(onConflict = OnConflictStrategy.Companion.IGNORE)
    suspend fun insertarIngrediente(ingrediente: Ingrediente): Long

    @Query("SELECT * FROM ingredientes ORDER BY nombre ASC")
    suspend fun obtenerTodosLosIngredientes(): List<Ingrediente>

    @Query("SELECT * FROM ingredientes WHERE id = :idIngrediente")
    suspend fun obtenerIngredientePorId(idIngrediente: Int): Ingrediente?
}