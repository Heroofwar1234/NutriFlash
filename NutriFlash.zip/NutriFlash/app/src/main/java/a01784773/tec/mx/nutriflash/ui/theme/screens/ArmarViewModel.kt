package a01784773.tec.mx.nutriflash.ui.theme.screens

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import a01784773.tec.mx.nutriflash.database.CocinaSaludableDatabase
import a01784773.tec.mx.nutriflash.database.IngredienteDao
import a01784773.tec.mx.nutriflash.database.RecetaDao
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.Normalizer

data class GameState(
    val currentRecipe: Recipe? = null,
    val requiredIngredients: List<Ingredient> = emptyList(),
    val selectedIngredients: Set<Ingredient> = emptySet(),
    val allIngredients: List<Ingredient> = emptyList(),
    val isRoundCompleted: Boolean = false,
    val score: Int = 0,
    val timeLeft: Float = 30f,
    val maxTime: Float = 30f,
    val isGameOver: Boolean = false
)

class ArmarViewModel(application: Application) : AndroidViewModel(application) {

    private val recetaDao: RecetaDao
    private val ingredienteDao: IngredienteDao
    private var timerJob: Job? = null

    private val _uiState = MutableStateFlow(GameState())
    val uiState: StateFlow<GameState> = _uiState.asStateFlow()

    init {
        val database = CocinaSaludableDatabase.obtenerBaseDeDatos(application, viewModelScope)
        recetaDao = database.recetaDao()
        ingredienteDao = database.ingredienteDao()

        viewModelScope.launch {
            val allIngredients = ingredienteDao.obtenerTodosLosIngredientes().map { 
                Ingredient(it.nombre, getResourceForIngredient(sanitizeForResourceName(it.nombre)))
            }
            _uiState.update { it.copy(allIngredients = allIngredients) }
            startNewRound()
        }
    }

    fun onIngredientSelected(ingredient: Ingredient) {
        if (_uiState.value.isGameOver) return

        _uiState.update {
            val newSelections = it.selectedIngredients + ingredient
            val isRoundCompleted = it.requiredIngredients.isNotEmpty() && newSelections.containsAll(it.requiredIngredients)
            it.copy(selectedIngredients = newSelections, isRoundCompleted = isRoundCompleted)
        }

        if (_uiState.value.isRoundCompleted) {
            val scoreToAdd = (5 * (_uiState.value.timeLeft * 10)).toInt()
            val newMaxTime = (_uiState.value.maxTime - 0.2f).coerceAtLeast(2f)

            _uiState.update {
                it.copy(
                    score = it.score + scoreToAdd,
                    maxTime = newMaxTime
                )
            }
            startNewRound()
        }
    }

    private fun startNewRound() {
        timerJob?.cancel()
        viewModelScope.launch {
            val newRecipeWithIngredients = recetaDao.obtenerTodasLasRecetasConIngredientes().randomOrNull()
            if (newRecipeWithIngredients != null) {
                val recipeEntity = newRecipeWithIngredients.receta
                val recipe = Recipe(
                    name = recipeEntity.nombre,
                    imageRes = getResourceForRecipe(recipeEntity.drawableName),
                    ingredients = newRecipeWithIngredients.ingredientes.map {
                        Ingredient(it.nombre, getResourceForIngredient(sanitizeForResourceName(it.nombre)))
                    }
                )

                _uiState.update {
                    it.copy(
                        currentRecipe = recipe,
                        requiredIngredients = recipe.ingredients,
                        selectedIngredients = emptySet(),
                        isRoundCompleted = false,
                        timeLeft = it.maxTime
                    )
                }

                timerJob = viewModelScope.launch {
                    while (_uiState.value.timeLeft > 0) {
                        delay(100)
                        _uiState.update { it.copy(timeLeft = it.timeLeft - 0.1f) }
                    }
                    _uiState.update { it.copy(isGameOver = true) }
                }
            } else {
                _uiState.update { it.copy(isGameOver = true) } // No more recipes
            }
        }
    }

    private fun sanitizeForResourceName(name: String): String {
        val normalized = Normalizer.normalize(name, Normalizer.Form.NFD)
        return "[\\p{InCombiningDiacriticalMarks}]".toRegex().replace(normalized, "").lowercase()
    }

    private fun getResourceForRecipe(drawableName: String): Int {
        val context: Context = getApplication()
        return context.resources.getIdentifier(drawableName, "drawable", context.packageName)
    }
    
    private fun getResourceForIngredient(drawableName: String): Int {
        val context: Context = getApplication()
        return context.resources.getIdentifier(drawableName, "drawable", context.packageName)
    }
}
