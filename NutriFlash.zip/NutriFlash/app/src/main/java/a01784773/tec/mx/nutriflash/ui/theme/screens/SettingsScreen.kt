package a01784773.tec.mx.nutriflash.ui.theme.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import a01784773.tec.mx.nutriflash.ui.theme.NutriFlashTheme
import androidx.navigation.NavController

@Composable
fun SettingsScreen(
    navController: NavController? = null,
    viewModel: SettingsViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
        ) {
            IconButton(
                onClick = { navController?.popBackStack() },
                modifier = Modifier.align(Alignment.CenterStart)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Return")
            }

            Text(
                "Configuración",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.align(Alignment.Center)
            )

            IconButton(
                onClick = {
                    navController?.navigate("main") {
                        popUpTo(navController.graph.startDestinationId) {
                            inclusive = true
                        }
                        launchSingleTop = true
                    }
                },
                modifier = Modifier.align(Alignment.CenterEnd)
            ) {
                Icon(Icons.Default.Home, contentDescription = "Home")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Profile Section
            ProfileSection(
                state = uiState,
                onNewProfileNameChange = viewModel::onNewProfileNameChange,
                onAddProfile = viewModel::onAddProfile,
                onProfileSelected = viewModel::onProfileSelected,
                onExpandProfiles = { viewModel.onExpandProfiles(!uiState.isProfileSectionExpanded) }
            )

            Divider()

            // Difficulty Section
            DifficultySection(
                selectedDifficulty = uiState.difficulty,
                onDifficultyChange = viewModel::onDifficultyChange
            )

            Divider()

            // Current Selections Display
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Perfil Actual: ${uiState.selectedProfile}")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Dificultad Actual: ${uiState.difficulty.name}")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfileSection(
    state: SettingsState,
    onNewProfileNameChange: (String) -> Unit,
    onAddProfile: () -> Unit,
    onProfileSelected: (String) -> Unit,
    onExpandProfiles: () -> Unit
) {
    Column(horizontalAlignment = Alignment.Start, modifier = Modifier.fillMaxWidth()) {
        Text("Perfil", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(bottom = 8.dp))

        ExposedDropdownMenuBox(
            expanded = state.isProfileSectionExpanded,
            onExpandedChange = { onExpandProfiles() }
        ) {
            OutlinedTextField(
                value = state.selectedProfile,
                onValueChange = {},
                readOnly = true,
                label = { Text("Perfil Seleccionado") },
                trailingIcon = { Icon(Icons.Default.ArrowDropDown, "Dropdown arrow") },
                modifier = Modifier
                    .menuAnchor() // This is important
                    .fillMaxWidth()
            )

            ExposedDropdownMenu(
                expanded = state.isProfileSectionExpanded,
                onDismissRequest = { onExpandProfiles() } // This should be onExpandProfiles(false) handled in VM
            ) {
                state.profiles.forEach { profile ->
                    DropdownMenuItem(
                        text = { Text(profile) },
                        onClick = { onProfileSelected(profile) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = state.newProfileName,
                onValueChange = onNewProfileNameChange,
                label = { Text("Agregar Perfil") },
                modifier = Modifier.weight(1f)
            )
            Button(onClick = onAddProfile, enabled = state.newProfileName.isNotBlank()) {
                Text("Agregar")
            }
        }
    }
}

@Composable
private fun DifficultySection(
    selectedDifficulty: Difficulty,
    onDifficultyChange: (Difficulty) -> Unit
) {
    Column(horizontalAlignment = Alignment.Start, modifier = Modifier.fillMaxWidth()) {
        Text("Dificultad", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(bottom = 8.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Difficulty.values().forEach { difficulty ->
                Button(
                    onClick = { onDifficultyChange(difficulty) },
                    colors = if (difficulty == selectedDifficulty) ButtonDefaults.buttonColors() else ButtonDefaults.outlinedButtonColors()
                ) {
                    Text(difficulty.name)
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SettingsScreenPreview() {
    NutriFlashTheme {
        SettingsScreen()
    }
}
