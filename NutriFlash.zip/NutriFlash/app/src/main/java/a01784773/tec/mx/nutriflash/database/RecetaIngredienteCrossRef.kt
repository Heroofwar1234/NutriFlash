package a01784773.tec.mx.nutriflash.database

import androidx.room.Entity

@Entity(primaryKeys = ["idReceta", "idIngrediente"])
data class RecetaIngredienteCrossRef(
    val idReceta: Int,
    val idIngrediente: Int
)
