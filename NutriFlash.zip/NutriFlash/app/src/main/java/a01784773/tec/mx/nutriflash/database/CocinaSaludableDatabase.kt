package a01784773.tec.mx.nutriflash.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.text.Normalizer

@Database(
    entities = [Receta::class, Ingrediente::class, RecetaIngredienteCrossRef::class],
    version = 5, // Incremented version to trigger recreation
    exportSchema = false
)
abstract class CocinaSaludableDatabase : RoomDatabase() {

    abstract fun recetaDao(): RecetaDao
    abstract fun ingredienteDao(): IngredienteDao

    companion object {
        @Volatile
        private var Instancia: CocinaSaludableDatabase? = null

        fun obtenerBaseDeDatos(contexto: Context, scope: CoroutineScope): CocinaSaludableDatabase {
            return Instancia ?: synchronized(this) {
                Room.databaseBuilder(
                    contexto.applicationContext,
                    CocinaSaludableDatabase::class.java,
                    "cocina_saludable_db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(BaseDeDatosCallback(scope))
                    .build()
                    .also { Instancia = it }
            }
        }
    }

    private class BaseDeDatosCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            Instancia?.let { database ->
                scope.launch {
                    poblarBaseDeDatos(database)
                }
            }
        }

        private fun sanitizeForResourceName(name: String): String {
            val normalized = Normalizer.normalize(name, Normalizer.Form.NFD)
            val regex = "\\p{InCombiningDiacriticalMarks}+".toRegex()
            return regex.replace(normalized, "").lowercase().replace(" ", "_")
        }

        private suspend fun poblarBaseDeDatos(db: CocinaSaludableDatabase) {
            val recetaDao = db.recetaDao()
            val ingredienteDao = db.ingredienteDao()

            if (recetaDao.contarRecetas() > 0) {
                return // Database already populated
            }

            val nombresIngredientes = listOf(
                "Tortillas", "Pollo", "Carne", "Huevo", "Queso",
                "Frijoles", "Arroz", "Tomate", "Cebolla", "Pan",
                "Limón", "Chile", "Aguacate", "Lechuga", "Elote", "Crema"
            )

            val ingredienteIdMap = mutableMapOf<String, Int>()
            nombresIngredientes.forEach { nombre ->
                val cleanName = sanitizeForResourceName(nombre)
                val id = ingredienteDao.insertarIngrediente(Ingrediente(nombre = nombre, drawableName = cleanName)).toInt()
                ingredienteIdMap[nombre] = id
            }

            val recetas = mapOf(
                "Tacos de Pollo" to listOf("Tortillas", "Pollo", "Cebolla", "Limón", "Chile", "Lechuga", "Crema"),
                "Quesadillas" to listOf("Tortillas", "Queso"),
                "Huevos a la Mexicana" to listOf("Huevo", "Tomate", "Cebolla", "Chile"),
                "Guacamole" to listOf("Aguacate", "Tomate", "Cebolla", "Chile", "Limón"),
                "Frijoles Refritos" to listOf("Frijoles", "Crema"),
                "Torta de Carne" to listOf("Pan", "Carne", "Lechuga", "Tomate"),
                "Ensalada" to listOf("Lechuga", "Tomate", "Cebolla", "Elote", "Crema"),
                "Enchiladas Rojas" to listOf("Tortillas", "Pollo", "Chile", "Queso", "Crema"),
                "Huevos Rancheros" to listOf("Tortillas", "Huevo", "Tomate", "Cebolla", "Chile"),
                "Tacos de carne asada" to listOf("Tortillas", "Carne", "Cebolla", "Limón", "Chile"),
                "Pico de gallo" to listOf("Tomate", "Cebolla", "Chile", "Limón"),
                "Chilaquiles Verdes" to listOf("Tortillas", "Queso", "Crema", "Chile"),
                "Sopes" to listOf("Tortillas", "Frijoles", "Queso", "Lechuga", "Crema"),
                "Molletes" to listOf("Pan", "Frijoles", "Queso"),
                "Tacos de Pastor" to listOf("Tortillas", "Carne", "Cebolla", "Limón", "Chile"),
                "Arroz con Pollo" to listOf("Arroz", "Pollo", "Tomate"),
                "Tacos de Huevo" to listOf("Tortillas", "Huevo", "Cebolla", "Chile"),
                "Burritos de Frijol y Queso" to listOf("Tortillas", "Frijoles", "Queso"),
                "Caldo de Pollo" to listOf("Pollo", "Tomate", "Cebolla", "Elote"),
                "Torta de Pollo" to listOf("Pan", "Pollo", "Lechuga", "Tomate"),
                "Huevos con Arroz" to listOf("Huevo", "Arroz"),
                "Frijol con puerco" to listOf("Frijoles", "Carne", "Arroz", "Cebolla", "Chile"),
                "Sopa de elote" to listOf("Elote", "Crema")
            )

            recetas.forEach { (nombreReceta, ingredientesReceta) ->
                val drawableName = sanitizeForResourceName(nombreReceta)
                val recetaId = recetaDao.insertarReceta(Receta(nombre = nombreReceta, drawableName = drawableName)).toInt()

                ingredientesReceta.forEach { nombreIng ->
                    val idIng = ingredienteIdMap[nombreIng]
                    if (idIng != null) {
                        recetaDao.insertarRelacion(
                            RecetaIngredienteCrossRef(
                                idReceta = recetaId,
                                idIngrediente = idIng
                            )
                        )
                    }
                }
            }
        }
    }
}