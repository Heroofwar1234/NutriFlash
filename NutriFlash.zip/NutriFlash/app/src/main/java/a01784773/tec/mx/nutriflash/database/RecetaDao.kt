package a01784773.tec.mx.nutriflash.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface RecetaDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarReceta(receta: Receta): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarRelacion(crossRef: RecetaIngredienteCrossRef)

    @Query("SELECT COUNT(*) FROM recetas")
    suspend fun contarRecetas(): Int

    @Transaction
    @Query("SELECT * FROM recetas WHERE id = :idReceta")
    suspend fun obtenerRecetaConIngredientes(idReceta: Int): RecetaConIngredientes?

    @Transaction
    @Query("SELECT * FROM recetas")
    suspend fun obtenerTodasLasRecetasConIngredientes(): List<RecetaConIngredientes>

    @Query("SELECT * FROM recetas ORDER BY nombre ASC")
    suspend fun obtenerTodasLasRecetas(): List<Receta>}