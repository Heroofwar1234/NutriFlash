package a01784773.tec.mx.nutriflash.ui.theme.screens

/**
 * Represents the game difficulty levels.
 */
enum class Difficulty {
    Facil, Intermedio, Dificil
}
