package a01784773.tec.mx.nutriflash.ui.theme.screens

import android.app.Application
import android.content.Context
import android.media.AudioManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import a01784773.tec.mx.nutriflash.database.CocinaSaludableDatabase
import a01784773.tec.mx.nutriflash.database.IngredienteDao
import a01784773.tec.mx.nutriflash.database.RecetaDao
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GameState(
    val currentRecipe: Recipe? = null,
    val requiredIngredients: List<Ingredient> = emptyList(),
    val selectedIngredients: Set<Ingredient> = emptySet(),
    val allIngredients: List<Ingredient> = emptyList(),
    val isRoundCompleted: Boolean = false,
    val score: Int = 0,
    val timeLeft: Float = 30f,
    val maxTime: Float = 30f,
    val isGameOver: Boolean = false
)

class ArmarViewModel(application: Application) : AndroidViewModel(application) {

    private lateinit var recetaDao: RecetaDao
    private lateinit var ingredienteDao: IngredienteDao
    private var timerJob: Job? = null
    private val audioManager: AudioManager

    private val _uiState = MutableStateFlow(GameState())
    val uiState: StateFlow<GameState> = _uiState.asStateFlow()

    init {
        audioManager = application.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        viewModelScope.launch {
            val database = CocinaSaludableDatabase.obtenerBaseDeDatos(application)
            CocinaSaludableDatabase.poblarSiEsNecesario(database)

            recetaDao = database.recetaDao()
            ingredienteDao = database.ingredienteDao()

            val startTime = getStartTimeForDifficulty()

            val allIngredients = ingredienteDao.obtenerTodosLosIngredientes().map { 
                Ingredient(it.nombre, getResourceForIngredient(it.drawableName))
            }
            _uiState.update { it.copy(allIngredients = allIngredients, maxTime = startTime, timeLeft = startTime) }
            
            startNewRound()
        }
    }

    fun onIngredientSelected(ingredient: Ingredient) {
        if (_uiState.value.isGameOver) return

        // Play sound based on whether the ingredient is correct or not
        if (_uiState.value.requiredIngredients.contains(ingredient)) {
            audioManager.playSoundEffect(AudioManager.FX_KEY_CLICK)
        } else {
            audioManager.playSoundEffect(AudioManager.FX_KEYPRESS_INVALID)
        }

        _uiState.update {
            val newSelections = it.selectedIngredients + ingredient
            val isRoundCompleted = it.requiredIngredients.isNotEmpty() && newSelections.containsAll(it.requiredIngredients)
            it.copy(selectedIngredients = newSelections, isRoundCompleted = isRoundCompleted)
        }

        if (_uiState.value.isRoundCompleted) {
            val scoreToAdd = (5 * (_uiState.value.timeLeft * 10)).toInt()
            val newMaxTime = (_uiState.value.maxTime - 0.2f).coerceAtLeast(2f)

            _uiState.update {
                it.copy(
                    score = it.score + scoreToAdd,
                    maxTime = newMaxTime
                )
            }
            startNewRound()
        }
    }
    
    fun playAgain() {
        val startTime = getStartTimeForDifficulty()
        _uiState.update {
            it.copy(
                score = 0,
                maxTime = startTime,
                timeLeft = startTime,
                isGameOver = false
            )
        }
        startNewRound()
    }

    private fun startNewRound() {
        // Play a sound to signal the start of a new round
        audioManager.playSoundEffect(AudioManager.FX_KEYPRESS_SPACEBAR)
        timerJob?.cancel()
        viewModelScope.launch {
            if (!::recetaDao.isInitialized || !::ingredienteDao.isInitialized) {
                return@launch
            }
            val newRecipeWithIngredients = recetaDao.obtenerTodasLasRecetasConIngredientes().randomOrNull()
            if (newRecipeWithIngredients != null) {
                val recipeEntity = newRecipeWithIngredients.receta
                val recipe = Recipe(
                    name = recipeEntity.nombre,
                    imageRes = getResourceForRecipe(recipeEntity.drawableName),
                    ingredients = newRecipeWithIngredients.ingredientes.map {
                        Ingredient(it.nombre, getResourceForIngredient(it.drawableName))
                    }
                )

                _uiState.update {
                    it.copy(
                        currentRecipe = recipe,
                        requiredIngredients = recipe.ingredients,
                        selectedIngredients = emptySet(),
                        isRoundCompleted = false,
                        timeLeft = it.maxTime
                    )
                }

                timerJob = viewModelScope.launch {
                    while (_uiState.value.timeLeft > 0) {
                        delay(100)
                        _uiState.update { it.copy(timeLeft = it.timeLeft - 0.1f) }
                    }
                    _uiState.update { it.copy(isGameOver = true) }
                }
            } else {
                _uiState.update { it.copy(isGameOver = true) }
            }
        }
    }

    private fun getStartTimeForDifficulty(): Float {
        val prefs = getApplication<Application>().getSharedPreferences("settings", Context.MODE_PRIVATE)
        val defaultDifficulty = Difficulty.Intermedio.name
        val difficultyName = prefs.getString("difficulty", defaultDifficulty) ?: defaultDifficulty
        val difficulty = try { Difficulty.valueOf(difficultyName) } catch (e: IllegalArgumentException) { Difficulty.Intermedio }
        
        return when (difficulty) {
            Difficulty.Facil -> 30f
            Difficulty.Intermedio -> 20f
            Difficulty.Dificil -> 10f
        }
    }

    private fun getResourceForRecipe(drawableName: String): Int {
        val context: Context = getApplication()
        return context.resources.getIdentifier(drawableName, "drawable", context.packageName)
    }
    
    private fun getResourceForIngredient(drawableName: String): Int {
        val context: Context = getApplication()
        return context.resources.getIdentifier(drawableName, "drawable", context.packageName)
    }
}
