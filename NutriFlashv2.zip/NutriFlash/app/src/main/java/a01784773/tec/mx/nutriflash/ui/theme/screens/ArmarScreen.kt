package a01784773.tec.mx.nutriflash.ui.theme.screens

import android.app.Application
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import a01784773.tec.mx.nutriflash.R
import a01784773.tec.mx.nutriflash.ui.theme.NutriFlashTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.navigation.NavController

data class Ingredient(val name: String, val imageRes: Int)

data class Recipe(val name: String, val imageRes: Int, val ingredients: List<Ingredient>)

@Composable
fun ArmarScreen(navController: NavController? = null) {
    val application = LocalContext.current.applicationContext as Application
    val viewModel: ArmarViewModel = viewModel(factory = ArmarViewModelFactory(application))
    val gameState by viewModel.uiState.collectAsState()

    if (gameState.isGameOver) {
        GameOverDialog(
            score = gameState.score,
            onPlayAgain = { viewModel.playAgain() }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFA726)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top bar with score, timer, and settings
        TopBar(navController, gameState)

        // Main content with character, bubble, and required ingredients
        MainContent(
            modifier = Modifier.weight(1f),
            gameState = gameState
        )

        // Bottom grid of selectable ingredients
        FoodGridSection(
            ingredients = gameState.allIngredients,
            onIngredientClick = { viewModel.onIngredientSelected(it) }
        )
    }
}

@Composable
private fun TopBar(navController: NavController?, gameState: GameState) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Puntaje: ${gameState.score}",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = gameState.timeLeft / gameState.maxTime,
                modifier = Modifier
                    .width(200.dp)
                    .height(20.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
        }
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(Color.White, CircleShape)
                .clickable { navController?.navigate("settings") }
                .align(Alignment.CenterEnd),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings"
            )
        }
    }
}

@Composable
private fun MainContent(modifier: Modifier = Modifier, gameState: GameState) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Character and Recipe
        Column(
            modifier = Modifier.padding(vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            gameState.currentRecipe?.let { recipe ->
                if (recipe.imageRes != 0) {
                    Image(
                        painter = painterResource(id = recipe.imageRes),
                        contentDescription = recipe.name,
                        modifier = Modifier
                            .size(120.dp)
                            .padding(bottom = 8.dp)
                    )
                }
            }
            Image(
                painter = painterResource(id = R.drawable.cliente1),
                contentDescription = "Person",
                modifier = Modifier.size(200.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Required ingredients list
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .background(Color(0xFFFFE082), RoundedCornerShape(16.dp))
                .padding(horizontal = 24.dp, vertical = 12.dp)
        ) {
            items(gameState.requiredIngredients) { ingredient ->
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .background(Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (ingredient.imageRes != 0) {
                        Image(
                            painter = painterResource(id = ingredient.imageRes),
                            contentDescription = ingredient.name,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
            }
        }
    }
}


@Composable
fun GameOverDialog(score: Int, onPlayAgain: () -> Unit) {
    AlertDialog(
        onDismissRequest = { /* Empty to force button click */ },
        title = { Text(text = "Game Over", style = MaterialTheme.typography.headlineMedium) },
        text = {
            Column {
                Text("Puntaje final: $score")
            }
        },
        confirmButton = {
            Button(onClick = onPlayAgain) {
                Text("Jugar de Nuevo")
            }
        }
    )
}

@Composable
fun FoodGridSection(
    modifier: Modifier = Modifier,
    ingredients: List<Ingredient>,
    onIngredientClick: (Ingredient) -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .background(Color(0xFFFFF3E0))
            .padding(vertical = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ingredients.chunked(4).forEach { rowIngredients ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    rowIngredients.forEach { ingredient ->
                        Surface(
                            modifier = Modifier
                                .size(60.dp)
                                .clickable { onIngredientClick(ingredient) },
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White,
                            shadowElevation = 4.dp
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (ingredient.imageRes != 0) {
                                    Image(
                                        painter = painterResource(id = ingredient.imageRes),
                                        contentDescription = ingredient.name,
                                        modifier = Modifier.size(55.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewArmarScreen() {
    NutriFlashTheme {
        // This preview will not work with the database-backed ViewModel.
        // You can create a mock ViewModel for preview purposes if needed.
    }
}
