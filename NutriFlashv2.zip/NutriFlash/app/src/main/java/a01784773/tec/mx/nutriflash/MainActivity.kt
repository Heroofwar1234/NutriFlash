package a01784773.tec.mx.nutriflash

import a01784773.tec.mx.nutriflash.ui.theme.screens.ArmarScreen
import a01784773.tec.mx.nutriflash.ui.theme.screens.SettingsScreen
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a01784773.tec.mx.nutriflash.ui.theme.NutriFlashTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.PlayArrow
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NutriFlashTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = "main") {
                        composable("main") { NutriFlashScreen(navController) }
                        composable("armar") { ArmarScreen(navController) }
                        composable("settings") { SettingsScreen(navController) }
                    }
                }
            }
        }
    }
}

@Composable
fun NutriFlashScreen(navController: NavController? = null) {
    // Soft vertical gradient background
    val background = Brush.verticalGradient(
        colors = listOf(Color(0xFFFFA726), Color(0xFFFFCC80))
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(brush = background)
            .padding(20.dp)
    ) {
        // Top Row: Settings button (top-right)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { navController?.navigate("settings") },
                modifier = Modifier
                    .size(44.dp)
                    .shadow(4.dp, CircleShape)
                    .background(Color.White.copy(alpha = 0.12f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = Color.White
                )
            }
        }

        // Main centered content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            // Title with mascot
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                // "Nutri" (accent color) and "FLASH" (white) split for visual identity
                Text(
                    text = "Nutri",
                    fontSize = 42.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF2E7D32) // deep green accent
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "FLASH",
                    fontSize = 42.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.width(12.dp))

                // Mascot image (round)
                Image(
                    painter = painterResource(id = R.drawable.ic_pear_placeholder), // PLACEHOLDER:
                    contentDescription = "Mascot",
                    modifier = Modifier
                        .size(56.dp)
                        .shadow(6.dp, CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Subtitle / small description (optional — keeps UI richer)
            Text(
                text = "Aprende jugando sobre comida saludable",
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.95f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Main big entry button
            Button(
                onClick = { navController?.navigate("armar") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
                    .shadow(8.dp, RoundedCornerShape(20.dp)),
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White)
            ) {
                // Left icon + text
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Enter Game",
                    tint = Color(0xFF2E7D32), // match green accent
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "ENTRAR AL JUEGO",
                    color = Color(0xFF2E7D32),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Small secondary hint (non-clickable for now)
            Text(
                text = "Pulsa el botón para comenzar",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.9f)
            )
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun NutriFlashPreview() {
    NutriFlashTheme {
        NutriFlashScreen()
    }
}
