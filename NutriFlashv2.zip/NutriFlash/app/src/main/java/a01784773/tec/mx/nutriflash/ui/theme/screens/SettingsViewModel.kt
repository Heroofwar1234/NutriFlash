package a01784773.tec.mx.nutriflash.ui.theme.screens

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class SettingsState(
    val profiles: List<String> = listOf("Default"),
    val selectedProfile: String = "Default",
    val newProfileName: String = "",
    val difficulty: Difficulty = Difficulty.Facil,
    val isProfileSectionExpanded: Boolean = false
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(SettingsState())
    val uiState: StateFlow<SettingsState> = _uiState.asStateFlow()

    private val prefs = application.getSharedPreferences("settings", Context.MODE_PRIVATE)

    init {
        // Load the saved difficulty on startup
        val savedDifficultyName = prefs.getString("difficulty", Difficulty.Facil.name)
        val savedDifficulty = try {
            Difficulty.valueOf(savedDifficultyName ?: Difficulty.Facil.name)
        } catch (e: IllegalArgumentException) {
            Difficulty.Facil
        }
        _uiState.update { it.copy(difficulty = savedDifficulty) }
    }

    fun onNewProfileNameChange(name: String) {
        _uiState.update { it.copy(newProfileName = name) }
    }

    fun onAddProfile() {
        _uiState.update { currentState ->
            if (currentState.newProfileName.isNotBlank() && !currentState.profiles.contains(currentState.newProfileName)) {
                currentState.copy(
                    profiles = currentState.profiles + currentState.newProfileName,
                    newProfileName = "" // Clear the text field
                )
            } else {
                currentState
            }
        }
    }

    fun onProfileSelected(profile: String) {
        _uiState.update { it.copy(selectedProfile = profile, isProfileSectionExpanded = false) }
    }

    fun onDifficultyChange(difficulty: Difficulty) {
        // Update the UI state
        _uiState.update { it.copy(difficulty = difficulty) }
        // Save the new difficulty to SharedPreferences
        with(prefs.edit()) {
            putString("difficulty", difficulty.name)
            apply()
        }
    }

    fun onExpandProfiles(isExpanded: Boolean) {
        _uiState.update { it.copy(isProfileSectionExpanded = isExpanded) }
    }
}
