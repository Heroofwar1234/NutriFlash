# NutriFlash

NutriFlash is an interactive Android game designed to help users learn about healthy Mexican food recipes in a fun and engaging way. The game challenges players to assemble recipes by selecting the correct ingredients against a timer.

## Gameplay

The core gameplay loop involves:
1.  A random recipe is displayed to the player.
2.  The player must select the correct ingredients from a grid of options.
3.  A timer counts down, adding pressure and excitement.
4.  Upon successfully completing a recipe, the player's score increases, the timer resets, and a new recipe is presented. The maximum time is slightly reduced to increase the challenge.
5.  The game ends when the timer runs out.

## Features

- **Dynamic Gameplay**: An interactive game loop with a progressively challenging timer.
- **Scoring System**: Players are scored based on how quickly they complete a recipe.
- **Adjustable Difficulty**: The game features three difficulty levels (Facil, Intermedio, Dificil) that change the starting time.
- **Settings Screen**: A dedicated screen to change the difficulty level and manage user profiles.
- **Sound Effects**: Audio feedback for correct/incorrect ingredient selections and for new rounds to enhance the user experience.
- **Local Database**: Uses a Room database to store and manage all recipe and ingredient data.
- **Modern UI**: Built entirely with Jetpack Compose for a declarative and modern user interface.

## Technologies & Architecture

- **Language**: [Kotlin](https://kotlinlang.org/)
- **UI Toolkit**: [Jetpack Compose](https://developer.android.com/jetpack/compose)
- **Architecture**: Model-View-ViewModel (MVVM)
- **State Management**: `StateFlow` to expose UI state from ViewModels.
- **Navigation**: [Jetpack Navigation for Compose](https://developer.android.com/jetpack/compose/navigation) to handle screen transitions.
- **Database**: [Room](https://developer.android.com/training/data-storage/room) for robust local data persistence.
- **Asynchronous Operations**: [Kotlin Coroutines](https://kotlinlang.org/docs/coroutines-overview.html) for managing background tasks like database access and timers.

### Key Dependencies

- `androidx.compose` (BOM, UI, Material3, Tooling)
- `androidx.navigation:navigation-compose:2.7.7`
- `androidx.lifecycle:lifecycle-viewmodel-compose:2.8.0`
- `androidx.room:room-runtime:2.8.2` & `room-ktx`
- `androidx.core:core-ktx:1.17.0`

## Project Structure

- `MainActivity.kt`: The main entry point for the app. Sets up the NavHost and theme.
- `ui/theme/screens/`: Contains all Jetpack Compose screens.
  - `ArmarScreen.kt`: The primary game screen.
  - `SettingsScreen.kt`: The screen for adjusting game settings.
- `ui/theme/screens/viewmodels/`: Contains the ViewModels for each screen.
  - `ArmarViewModel.kt`: Handles the core game logic, including the timer, scoring, and recipe management.
  - `SettingsViewModel.kt`: Manages saving and retrieving user settings like difficulty.
- `database/`: Contains all Room database components.
  - `CocinaSaludableDatabase.kt`: The Room database definition and pre-population logic.
  - `RecetaDao.kt` & `IngredienteDao.kt`: Data Access Objects for database queries.

## How to Build

1.  Clone this repository to your local machine.
2.  Open the project in Android Studio.
3.  Allow Gradle to sync and download all the required dependencies.
4.  Build and run the app on an Android emulator or a physical device.
